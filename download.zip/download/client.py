import socket
import threading
from crypto_utils import *

HOST = "127.0.0.1"
PORT = 5000

def ricevi_messaggi(sock, session_key):
    while True:
        try:
            data = sock.recv(4096)
            if not data:
                break
            print(decripta_aes(session_key, data).decode())
        except:
            break

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))

    
    server_public_key = s.recv(2048)

    
    session_key = genera_chiave_sessione()
    s.sendall(cripta_rsa(server_public_key, session_key))

    
    username = input("Username: ")
    s.sendall(cripta_aes(session_key, username.encode()))

    print("Connessione sicura stabilita")

    threading.Thread(
        target=ricevi_messaggi,
        args=(s, session_key),
        daemon=True
    ).start()

    while True:
        msg = input()
        if msg.lower() == "exit":
            break
        s.sendall(cripta_aes(session_key, msg.encode()))
