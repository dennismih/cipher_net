# pip install pycryptodome, python 3.11/3.12
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import base64

def genera_chiavi_rsa():
    key = RSA.generate(2048)
    return key.export_key(), key.publickey().export_key()

def cripta_rsa(public_key_bytes, data):
    pub_key = RSA.import_key(public_key_bytes)
    cipher = PKCS1_OAEP.new(pub_key)
    return cipher.encrypt(data)

def decripta_rsa(private_key_bytes, ciphertext):
    priv_key = RSA.import_key(private_key_bytes)
    cipher = PKCS1_OAEP.new(priv_key)
    return cipher.decrypt(ciphertext)

def genera_chiave_sessione():
    return get_random_bytes(16)

def cripta_aes(key, plaintext):
    cipher = AES.new(key, AES.MODE_CBC)
    ct = cipher.encrypt(pad(plaintext, AES.block_size))
    return base64.b64encode(cipher.iv + ct)

def decripta_aes(key, ciphertext_b64):
    raw = base64.b64decode(ciphertext_b64)
    iv = raw[:16]
    ct = raw[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(ct), AES.block_size)
