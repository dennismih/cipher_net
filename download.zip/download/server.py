import socket
import threading
from crypto_utils import *

HOST = "127.0.0.1"
PORT = 5000

private_key, public_key = genera_chiavi_rsa()
clients = {} 

def broadcast(sender_conn, message):
    sender_name = clients[sender_conn][0]
    for conn, (_, key) in clients.items():
        if conn != sender_conn:
            encrypted = cripta_aes(key, f"{sender_name}: {message}".encode())
            conn.sendall(encrypted)

def gestione_client_chat(conn):
    try:
        
        conn.sendall(public_key)

        
        encrypted_session_key = conn.recv(256)
        session_key = decripta_rsa(private_key, encrypted_session_key)

        
        encrypted_username = conn.recv(4096)
        username = decripta_aes(session_key, encrypted_username).decode()

        clients[conn] = (username, session_key)
        print(f"[+] {username} connesso")

        broadcast(conn, f"è entrato in chat")

        while True:
            encrypted_msg = conn.recv(4096)
            if not encrypted_msg:
                break

            msg = decripta_aes(session_key, encrypted_msg).decode()
            broadcast(conn, msg)

    except Exception as e:
        print("Errore:", e)

    finally:
        if conn in clients:
            name = clients[conn][0]
            clients.pop(conn)
            broadcast(conn, f"è uscito dalla chat")
            print(f"[-] {name} disconnesso")
        conn.close()

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    print("Server in ascolto...")

    while True:
        conn, addr = s.accept()
        threading.Thread(target=gestione_client_chat, args=(conn,), daemon=True).start()
